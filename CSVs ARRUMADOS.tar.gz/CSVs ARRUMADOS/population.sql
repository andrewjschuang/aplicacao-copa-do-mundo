--Antes de executar esse script certifique-se que todos os arquivos estão no /tmp na pasta csvs
--INSERE PESSOA
COPY pessoa FROM '/tmp/csvs/pessoa.csv'  DELIMITER ';' CSV HEADER;
--INSERE TORCEDORES
COPY torcedor(email,idpessoa,senha) FROM '/tmp/csvs/torcedor.csv'  DELIMITER ',' CSV HEADER;
--INSERE CIDADES
INSERT INTO cidade VALUES('Moscow',to_timestamp(-25971408000));
INSERT INTO cidade VALUES('Kaliningrad',to_timestamp(-22542192000));
INSERT INTO cidade VALUES('Saint Petersburg',to_timestamp(-8413113600));
INSERT INTO cidade VALUES('Sochi',to_timestamp(-4165516800));
INSERT INTO cidade VALUES('Rostov-on-Don',to_timestamp(-6974035200));
INSERT INTO cidade VALUES('Volgograd',to_timestamp(-12023164800));
INSERT INTO cidade VALUES('Kazan',to_timestamp(-30452457600));
INSERT INTO cidade VALUES('Nizhny Novgorod',to_timestamp(-23633164800));
INSERT INTO cidade VALUES('Samara',to_timestamp(-12117859200));
INSERT INTO cidade VALUES('Yekaterinburg',to_timestamp(-7766841600));
INSERT INTO cidade VALUES('Saransk',to_timestamp(-10382169600));
--INSERE SELCAO
COPY selecao FROM '/tmp/csvs/selecao.csv'  DELIMITER ',' CSV HEADER;
--INSERE MEMBRO SELECAO
COPY membro_selecao FROM '/tmp/csvs/membro_selecao.csv'  DELIMITER ';' CSV HEADER;
--INSERE HOTEL
COPY hotel FROM '/tmp/csvs/hotel.csv'  DELIMITER ';' CSV HEADER;
--INSERE GUIA VOLUNTARIO
COPY guia_voluntario FROM '/tmp/csvs/guias.csv'  DELIMITER ';' CSV HEADER;
--INSERE VIAGEM
COPY viagem FROM '/tmp/csvs/viagem.csv'  DELIMITER ';' CSV HEADER;
--INSERE TRADUTOR
COPY tradutor FROM '/tmp/csvs/tradutor.csv'  DELIMITER ';' CSV HEADER;
--INSERE AJUDA
COPY ajuda FROM '/tmp/csvs/ajuda.csv'  DELIMITER ',' CSV HEADER;
-- INSERE CONTRATA
COPY contrata FROM '/tmp/csvs/contrata.csv'  DELIMITER ';' CSV HEADER;
--INSERE PARTIDA
COPY partida(codpartida,datapartida,valoringresso,golselecao1,golselecao2,nomecidade,idselecao1,idselecao2) FROM '/tmp/csvs/partida.csv'  DELIMITER ';' CSV HEADER;
--INSERE EVENTO
COPY evento FROM '/tmp/csvs/evento.csv'  DELIMITER ';' CSV HEADER;
--INSERE COMPRA INGRESSO
COPY compraingresso FROM '/tmp/csvs/compraingresso.csv'  DELIMITER ';' CSV HEADER;
--INSERE INTERESSE
COPY interesse FROM '/tmp/csvs/interesse.csv'  DELIMITER ';' CSV HEADER;
